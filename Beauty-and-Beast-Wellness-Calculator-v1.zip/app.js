'use strict';

const ENGINE_VERSION = '1.0.0';
const U100 = 100;
const app = document.querySelector('#app');
const toast = document.querySelector('#toast');

const seed = {
  profile: 'Beast',
  theme: 'dark',
  vials: [],
  regimens: { Beast: [], Beauty: [] },
  events: [],
  history: []
};

let state = load();
let view = 'today';

function load(){
  try { return { ...structuredClone(seed), ...JSON.parse(localStorage.getItem('bbwc-state')||'{}') }; }
  catch { return structuredClone(seed); }
}
function save(){ localStorage.setItem('bbwc-state', JSON.stringify(state)); }
function uid(){ return crypto.randomUUID ? crypto.randomUUID() : `${Date.now()}-${Math.random()}`; }
function esc(s=''){ return String(s).replace(/[&<>'"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c])); }
function n(v){ const x=Number(v); return Number.isFinite(x)?x:NaN; }
function fmt(v,d=3){ return Number(v).toLocaleString(undefined,{maximumFractionDigits:d}); }
function mg(value, unit){ return unit==='mcg' ? value/1000 : value; }
function showToast(msg){ toast.textContent=msg; toast.classList.add('show'); setTimeout(()=>toast.classList.remove('show'),1800); }
function todayKey(){ return new Date().toISOString().slice(0,10); }
function applyTheme(){ document.documentElement.classList.toggle('light',state.theme==='light'); }

function vialConcentration(vial, ingredientIndex=0){
  const ing=vial.ingredients[ingredientIndex];
  return mg(ing.amount,ing.unit)/vial.diluentMl;
}
function totalUsedMg(vialId){
  return state.history.filter(h=>h.vialId===vialId && h.type==='injection').reduce((s,h)=>s+h.totalVialMgUsed,0);
}
function vialTotalMg(vial){ return vial.ingredients.reduce((s,i)=>s+mg(i.amount,i.unit),0); }
function remainingMg(vial){ return Math.max(0,vialTotalMg(vial)-totalUsedMg(vial.id)); }
function remainingMl(vial){ return vialTotalMg(vial)>0 ? vial.diluentMl*(remainingMg(vial)/vialTotalMg(vial)) : 0; }
function status(vial){ const pct=remainingMg(vial)/vialTotalMg(vial); return pct<=0?['Empty','status-empty']:pct<.2?['Running Low','status-low']:['Good','status-good']; }

function doseToUnits(vial, ingredientIndex, dose, doseUnit, syringe=U100){
  const doseMg=mg(dose,doseUnit);
  const c=vialConcentration(vial,ingredientIndex);
  if(!(doseMg>0) || !(c>0)) throw new Error('Enter a valid dose and vial.');
  const ml=doseMg/c;
  const units=ml*syringe;
  return {doseMg, concentration:c, ml, units, math:`Ingredient concentration = ${fmt(mg(vial.ingredients[ingredientIndex].amount,vial.ingredients[ingredientIndex].unit),6)} mg ÷ ${fmt(vial.diluentMl,6)} mL = ${fmt(c,6)} mg/mL\nRequired volume = ${fmt(doseMg,6)} mg ÷ ${fmt(c,6)} mg/mL = ${fmt(ml,6)} mL\nSyringe units = ${fmt(ml,6)} mL × ${syringe} units/mL = ${fmt(units,3)} units`};
}
function unitsToDose(vial, units, syringe=U100){
  if(!(units>=0)) throw new Error('Enter valid syringe units.');
  const ml=units/syringe;
  const delivered=vial.ingredients.map(i=>({name:i.name, mg:(mg(i.amount,i.unit)/vial.diluentMl)*ml}));
  return {ml,delivered,math:`Volume = ${fmt(units,3)} units ÷ ${syringe} units/mL = ${fmt(ml,6)} mL\n`+delivered.map(i=>`${i.name}: ${fmt(i.mg,6)} mg delivered`).join('\n')};
}
function compareVials(oldVial,newVial,oldUnits,ingredientIndex=0,syringe=U100){
  const oldDose=unitsToDose(oldVial,oldUnits,syringe).delivered[ingredientIndex]?.mg;
  if(!(oldDose>=0)) throw new Error('Unable to compare these vials.');
  const result=doseToUnits(newVial,ingredientIndex,oldDose,'mg',syringe);
  return {...result, oldDose, math:`Old vial delivers ${fmt(oldDose,6)} mg at ${fmt(oldUnits,3)} units.\nNew vial equivalent:\n${result.math}`};
}

function navHTML(){
  document.querySelectorAll('.bottom-nav button').forEach(b=>b.classList.toggle('active',b.dataset.nav===view));
}
function profileSwitch(){ return `<div class="profile-switch"><button data-profile="Beast" class="${state.profile==='Beast'?'active':''}">Beast</button><button data-profile="Beauty" class="${state.profile==='Beauty'?'active':''}">Beauty</button></div>`; }

function render(){
  applyTheme(); navHTML();
  if(view==='today') renderToday();
  if(view==='calculate') renderCalculate();
  if(view==='vials') renderVials();
  if(view==='history') renderHistory();
}

function renderToday(){
  const today=new Date().getDay();
  const due=state.regimens[state.profile].filter(r=>r.days.includes(today));
  app.innerHTML=`${profileSwitch()}<div class="card"><div class="row space"><div><h2>Today's Regimen</h2><div class="muted small">${new Date().toLocaleDateString(undefined,{weekday:'long',month:'long',day:'numeric'})}</div></div><span class="pill">${state.profile}</span></div></div>${due.length?due.map(r=>{
    const done=state.history.find(h=>h.type==='injection'&&h.profile===state.profile&&h.regimenId===r.id&&h.dateKey===todayKey());
    return `<div class="card"><div class="row space"><div><h3>${esc(r.name)}</h3><div class="muted">${fmt(r.dose)} ${esc(r.doseUnit)}</div></div>${done?`<span class="pill status-good">Completed ${new Date(done.createdAt).toLocaleTimeString([], {hour:'numeric',minute:'2-digit'})}</span>`:`<button class="btn primary" data-regcalc="${r.id}">Calculate</button>`}</div></div>`;
  }).join(''):`<div class="card empty">Nothing scheduled today.</div>`}
  <div class="card"><div class="row space"><h3>Regimens</h3><button class="btn" id="addRegimen">Add item</button></div><div class="small muted">Schedule items by profile and day of week.</div></div>`;
}

function renderCalculate(prefill={}){
  const vialOptions=state.vials.map(v=>`<option value="${v.id}" ${prefill.vialId===v.id?'selected':''}>${esc(v.name)}</option>`).join('');
  app.innerHTML=`<div class="card"><h2>What do you know?</h2><div class="grid two">
    <button class="btn mode" data-mode="dose-units">I know my dose</button>
    <button class="btn mode" data-mode="units-dose">I know syringe units</button>
    <button class="btn mode" data-mode="compare">Compare two vials</button>
    <button class="btn mode" data-mode="new-vial">Add or mix a vial</button>
  </div></div><div id="calcArea"></div>`;
  if(prefill.mode) openMode(prefill.mode,prefill);
}

function openMode(mode,prefill={}){
  const area=document.querySelector('#calcArea');
  if(mode==='new-vial'){ view='vials'; renderVials(true); return; }
  if(state.vials.length===0){ area.innerHTML='<div class="card empty">Add a vial first.</div>'; return; }
  const options=state.vials.map(v=>`<option value="${v.id}" ${prefill.vialId===v.id?'selected':''}>${esc(v.name)}</option>`).join('');
  if(mode==='dose-units') area.innerHTML=`<form id="doseForm" class="card"><h3>Dose → Units</h3><div class="grid two"><div><label>Vial</label><select name="vialId">${options}</select></div><div><label>Ingredient</label><select name="ingredientIndex"></select></div><div><label>Desired dose</label><input name="dose" type="number" step="any" min="0" value="${prefill.dose??''}" required></div><div><label>Unit</label><select name="doseUnit"><option>mg</option><option>mcg</option></select></div><div><label>Syringe</label><select name="syringe"><option value="100">U-100</option><option value="40">U-40</option></select></div></div><button class="btn primary block" type="submit">Calculate</button></form><div id="result"></div>`;
  if(mode==='units-dose') area.innerHTML=`<form id="unitsForm" class="card"><h3>Units → Dose</h3><div class="grid two"><div><label>Vial</label><select name="vialId">${options}</select></div><div><label>Syringe units</label><input name="units" type="number" step="any" min="0" required></div><div><label>Syringe</label><select name="syringe"><option value="100">U-100</option><option value="40">U-40</option></select></div></div><button class="btn primary block" type="submit">Calculate</button></form><div id="result"></div>`;
  if(mode==='compare') area.innerHTML=`<form id="compareForm" class="card"><h3>Vial Equivalency</h3><div class="grid two"><div><label>Old vial</label><select name="oldVial">${options}</select></div><div><label>Old syringe units</label><input name="oldUnits" type="number" step="any" min="0" required></div><div><label>New vial</label><select name="newVial">${options}</select></div><div><label>Syringe</label><select name="syringe"><option value="100">U-100</option><option value="40">U-40</option></select></div></div><button class="btn primary block" type="submit">Compare</button></form><div id="result"></div>`;
  bindCalcForms(prefill);
}

function fillIngredients(select,vialId,selected=0){
  const vial=state.vials.find(v=>v.id===vialId); if(!vial)return;
  select.innerHTML=vial.ingredients.map((i,idx)=>`<option value="${idx}" ${idx===Number(selected)?'selected':''}>${esc(i.name)}</option>`).join('');
}
function bindCalcForms(prefill){
  const doseForm=document.querySelector('#doseForm');
  if(doseForm){ fillIngredients(doseForm.ingredientIndex,doseForm.vialId.value,prefill.ingredientIndex||0); doseForm.vialId.onchange=()=>fillIngredients(doseForm.ingredientIndex,doseForm.vialId.value); doseForm.onsubmit=e=>{e.preventDefault(); try{ const vial=state.vials.find(v=>v.id===doseForm.vialId.value); const idx=n(doseForm.ingredientIndex.value); const r=doseToUnits(vial,idx,n(doseForm.dose.value),doseForm.doseUnit.value,n(doseForm.syringe.value)); showDoseResult(vial,idx,r,prefill.regimenId); }catch(err){showToast(err.message);} }; }
  const unitsForm=document.querySelector('#unitsForm');
  if(unitsForm) unitsForm.onsubmit=e=>{e.preventDefault(); try{ const vial=state.vials.find(v=>v.id===unitsForm.vialId.value); const r=unitsToDose(vial,n(unitsForm.units.value),n(unitsForm.syringe.value)); document.querySelector('#result').innerHTML=`<div class="card"><div class="big-result">${fmt(r.ml,4)} mL</div>${r.delivered.map(i=>`<div>${esc(i.name)}: <strong>${fmt(i.mg,6)} mg</strong></div>`).join('')}<details><summary>Show My Math</summary><pre class="math">${esc(r.math)}</pre></details></div>`;}catch(err){showToast(err.message);} };
  const compareForm=document.querySelector('#compareForm');
  if(compareForm) compareForm.onsubmit=e=>{e.preventDefault();try{const oldV=state.vials.find(v=>v.id===compareForm.oldVial.value), newV=state.vials.find(v=>v.id===compareForm.newVial.value);const r=compareVials(oldV,newV,n(compareForm.oldUnits.value),0,n(compareForm.syringe.value));document.querySelector('#result').innerHTML=`<div class="card"><div class="muted">Equivalent on new vial</div><div class="big-result">${fmt(r.units,3)} units</div><div>${fmt(r.ml,6)} mL</div><details><summary>Show My Math</summary><pre class="math">${esc(r.math)}</pre></details></div>`;}catch(err){showToast(err.message);} };
}
function showDoseResult(vial,idx,r,regimenId){
  const ingredient=vial.ingredients[idx];
  const totalRatio=vialTotalMg(vial)/mg(ingredient.amount,ingredient.unit);
  const totalVialMgUsed=r.doseMg*totalRatio;
  const tooMuch=totalVialMgUsed>remainingMg(vial)+1e-9;
  document.querySelector('#result').innerHTML=`<div class="card"><div class="muted">Draw</div><div class="big-result">${fmt(r.units,3)} units</div><div>${fmt(r.ml,6)} mL • ${fmt(r.doseMg,6)} mg ${esc(ingredient.name)}</div>${tooMuch?'<p class="status-empty"><strong>Not enough remains in this vial.</strong></p>':`<button class="btn primary block" id="recordInjection">Record Injection</button>`}<details><summary>Show My Math</summary><pre class="math">${esc(r.math)}</pre></details></div>`;
  const btn=document.querySelector('#recordInjection');
  if(btn) btn.onclick=()=>recordInjection({vial,ingredient,idx,r,totalVialMgUsed,regimenId});
}
function recordInjection(data){
  const entry={id:uid(),type:'injection',profile:state.profile,vialId:data.vial.id,vialName:data.vial.name,ingredient:data.ingredient.name,doseMg:data.r.doseMg,units:data.r.units,ml:data.r.ml,totalVialMgUsed:data.totalVialMgUsed,regimenId:data.regimenId||null,dateKey:todayKey(),createdAt:new Date().toISOString(),engineVersion:ENGINE_VERSION,math:data.r.math};
  const before=JSON.stringify(state);
  try{ if(data.totalVialMgUsed>remainingMg(data.vial)+1e-9) throw new Error('Not enough remains in this vial.'); state.history.push(entry); state.events.push({id:uid(),type:'InjectionRecorded',entryId:entry.id,createdAt:entry.createdAt}); save(); showToast('Injection recorded'); view='today'; render(); }
  catch(err){ state=JSON.parse(before); showToast(err.message); }
}

function renderVials(openForm=false){
  app.innerHTML=`<div class="card"><div class="row space"><div><h2>Shared Vials</h2><div class="muted small">Used by Beauty and Beast</div></div><button class="btn primary" id="newVialBtn">Add Vial</button></div></div><div id="vialForm"></div>${state.vials.length?state.vials.map(v=>{const [label,cls]=status(v);return `<div class="card"><div class="row space"><div><h3>${esc(v.name)}</h3><div class="muted">${v.ingredients.map(i=>`${esc(i.name)} ${fmt(i.amount)} ${i.unit}`).join(' + ')} in ${fmt(v.diluentMl)} mL</div></div><span class="pill ${cls}">${label}</span></div><hr><div class="grid two"><div><div class="muted small">Remaining</div><strong>${fmt(remainingMg(v),3)} mg total</strong></div><div><div class="muted small">Estimated volume</div><strong>${fmt(remainingMl(v),3)} mL</strong></div></div><div class="row wrap" style="margin-top:12px"><button class="btn" data-edit-vial="${v.id}">Edit</button><button class="btn danger" data-delete-vial="${v.id}">Delete</button></div></div>`}).join(''):'<div class="card empty">No vials saved yet.</div>'}`;
  document.querySelector('#newVialBtn').onclick=()=>vialForm();
  if(openForm) vialForm();
}
function vialForm(existing=null){
  const host=document.querySelector('#vialForm');
  const ingredients=existing?.ingredients||[{name:'',amount:'',unit:'mg'}];
  host.innerHTML=`<form id="vialEditor" class="card"><h3>${existing?'Edit':'Add'} Vial</h3><div><label>Vial name</label><input name="name" value="${esc(existing?.name||'')}" required></div><div id="ingredients">${ingredients.map((i,idx)=>ingredientRow(i,idx)).join('')}</div><button class="btn" type="button" id="addIngredient">Add ingredient</button><div style="margin-top:12px"><label>Diluent volume (mL)</label><input name="diluentMl" type="number" step="any" min="0.001" value="${existing?.diluentMl||''}" required></div><button class="btn primary block" type="submit" style="margin-top:12px">Save Vial</button></form>`;
  let count=ingredients.length;
  document.querySelector('#addIngredient').onclick=()=>{document.querySelector('#ingredients').insertAdjacentHTML('beforeend',ingredientRow({name:'',amount:'',unit:'mg'},count++));};
  document.querySelector('#vialEditor').onsubmit=e=>{e.preventDefault();const f=e.currentTarget;const names=[...f.querySelectorAll('[name="ingName"]')],amounts=[...f.querySelectorAll('[name="ingAmount"]')],units=[...f.querySelectorAll('[name="ingUnit"]')];const ings=names.map((el,i)=>({name:el.value.trim(),amount:n(amounts[i].value),unit:units[i].value})).filter(i=>i.name&&i.amount>0);if(!ings.length){showToast('Add at least one valid ingredient.');return;}const vial={id:existing?.id||uid(),name:f.name.value.trim(),ingredients:ings,diluentMl:n(f.diluentMl.value),createdAt:existing?.createdAt||new Date().toISOString()};if(!(vial.diluentMl>0)){showToast('Enter a valid diluent volume.');return;}if(existing) state.vials=state.vials.map(v=>v.id===existing.id?vial:v);else {state.vials.push(vial);state.events.push({id:uid(),type:'VialCreated',vialId:vial.id,createdAt:new Date().toISOString()});}save();renderVials();showToast('Vial saved');};
}
function ingredientRow(i,idx){return `<div class="grid three" style="margin-top:10px"><div><label>Ingredient</label><input name="ingName" value="${esc(i.name)}" required></div><div><label>Amount</label><input name="ingAmount" type="number" step="any" min="0" value="${i.amount}" required></div><div><label>Unit</label><select name="ingUnit"><option ${i.unit==='mg'?'selected':''}>mg</option><option ${i.unit==='mcg'?'selected':''}>mcg</option></select></div></div>`;}

function renderHistory(){
  const items=[...state.history].reverse();
  app.innerHTML=`${profileSwitch()}<div class="card"><div class="row space"><div><h2>History</h2><div class="muted small">Immutable calculation records</div></div>${items.length?'<button class="btn" id="undoLast">Undo Last Injection</button>':''}</div></div>${items.length?items.map(h=>`<div class="card"><div class="row space"><div><h3>${esc(h.ingredient)}</h3><div class="muted">${esc(h.profile)} • ${new Date(h.createdAt).toLocaleString()}</div></div><span class="pill">${fmt(h.units,3)} units</span></div><div>${fmt(h.doseMg,6)} mg from ${esc(h.vialName)}</div><details><summary>Show My Math</summary><pre class="math">${esc(h.math)}</pre></details></div>`).join(''):'<div class="card empty">No recorded injections.</div>'}`;
  const undo=document.querySelector('#undoLast'); if(undo) undo.onclick=()=>{const last=state.history[state.history.length-1];if(!last)return;state.history.pop();state.events.push({id:uid(),type:'InjectionUndone',entryId:last.id,createdAt:new Date().toISOString()});save();renderHistory();showToast('Last injection undone');};
}

function addRegimen(){
  if(!state.vials.length){showToast('Add a vial first.');view='vials';render();return;}
  const options=state.vials.map(v=>`<option value="${v.id}">${esc(v.name)}</option>`).join('');
  app.innerHTML=`${profileSwitch()}<form id="regimenForm" class="card"><h2>Add Regimen Item</h2><div class="grid two"><div><label>Name</label><input name="name" required></div><div><label>Vial</label><select name="vialId">${options}</select></div><div><label>Ingredient</label><select name="ingredientIndex"></select></div><div><label>Dose</label><input name="dose" type="number" step="any" min="0" required></div><div><label>Dose unit</label><select name="doseUnit"><option>mg</option><option>mcg</option></select></div></div><label style="margin-top:12px">Days</label><div class="row wrap">${['Sun','Mon','Tue','Wed','Thu','Fri','Sat'].map((d,i)=>`<label class="pill"><input type="checkbox" name="days" value="${i}" style="width:auto"> ${d}</label>`).join('')}</div><button class="btn primary block" type="submit" style="margin-top:12px">Save</button></form>`;
  const f=document.querySelector('#regimenForm'); fillIngredients(f.ingredientIndex,f.vialId.value); f.vialId.onchange=()=>fillIngredients(f.ingredientIndex,f.vialId.value); f.onsubmit=e=>{e.preventDefault();const days=[...f.querySelectorAll('[name="days"]:checked')].map(x=>Number(x.value));if(!days.length){showToast('Choose at least one day.');return;}state.regimens[state.profile].push({id:uid(),name:f.name.value.trim(),vialId:f.vialId.value,ingredientIndex:Number(f.ingredientIndex.value),dose:n(f.dose.value),doseUnit:f.doseUnit.value,days});save();view='today';render();showToast('Regimen saved');};
}

document.addEventListener('click',e=>{
  const nav=e.target.closest('[data-nav]'); if(nav){view=nav.dataset.nav;render();return;}
  const prof=e.target.closest('[data-profile]'); if(prof){state.profile=prof.dataset.profile;save();render();return;}
  const mode=e.target.closest('[data-mode]'); if(mode){openMode(mode.dataset.mode);return;}
  const rc=e.target.closest('[data-regcalc]'); if(rc){const r=state.regimens[state.profile].find(x=>x.id===rc.dataset.regcalc);view='calculate';renderCalculate({mode:'dose-units',vialId:r.vialId,ingredientIndex:r.ingredientIndex,dose:r.dose,regimenId:r.id});return;}
  if(e.target.id==='addRegimen'){addRegimen();return;}
  const edit=e.target.closest('[data-edit-vial]'); if(edit){vialForm(state.vials.find(v=>v.id===edit.dataset.editVial));return;}
  const del=e.target.closest('[data-delete-vial]'); if(del){const id=del.dataset.deleteVial;if(state.history.some(h=>h.vialId===id)){showToast('Cannot delete a vial with history.');return;}state.vials=state.vials.filter(v=>v.id!==id);save();renderVials();return;}
});

document.querySelector('#themeBtn').onclick=()=>{state.theme=state.theme==='dark'?'light':'dark';save();render();};
if('serviceWorker' in navigator) navigator.serviceWorker.register('./sw.js').catch(()=>{});
render();

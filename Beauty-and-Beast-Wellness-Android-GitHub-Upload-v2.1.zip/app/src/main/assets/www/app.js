const $ = (s, el=document) => el.querySelector(s);

function showError(message){
  const banner=$("#errorBanner");
  if(!banner)return;
  banner.textContent=message;
  banner.classList.remove("hidden");
  setTimeout(()=>banner.classList.add("hidden"),7000);
}
window.addEventListener("error",e=>{
  console.error(e.error||e.message);
  showError("The app hit an unexpected error. Your saved data was not deleted.");
});
window.addEventListener("unhandledrejection",e=>{
  console.error(e.reason);
  showError("A background action failed. Please try again.");
});

const $$ = (s, el=document) => [...el.querySelectorAll(s)];
const STORAGE_KEY = "bbw-v1-data";
const SNAPSHOT_KEY = "bbw-v2-safety-snapshot";
const DATA_SCHEMA_VERSION = 2;

const defaultData = {
  schemaVersion: DATA_SCHEMA_VERSION,
  theme: "dark",
  activeProfile: "Beast",
  dashboardLastOpened: "",
  onboardingComplete: false,
  history: [],
  activity: [],
  reminders: [],
  vials: [],
  protocols: [
    {
      id:"beast-retatrutide", profile:"Beast", name:"Retatrutide weekly titration", item:"Retatrutide / GLP-3R",
      vialMg:60, liquidMl:3, doseUnit:"mg", notes:"Once weekly on the same chosen day. Increase only as needed.",
      currentStep:0,
      steps:[
        {label:"Week 1",dose:0.5,units:2.5,guidance:"Starting dose"},
        {label:"Week 2",dose:1.0,units:5,guidance:"Increase only if needed"},
        {label:"Week 3",dose:1.5,units:7.5,guidance:"Increase only if needed"},
        {label:"Week 4",dose:2.0,units:10,guidance:"Increase only if needed"},
        {label:"Week 5",dose:2.5,units:12.5,guidance:"Increase only if needed"},
        {label:"Week 6+",dose:3.0,units:15,guidance:"Top dose included in this personal protocol"}
      ]
    },
    {
      id:"beast-tesamorelin", profile:"Beast", name:"Tesamorelin nightly starter", item:"Tesamorelin",
      vialMg:10, liquidMl:2, doseUnit:"mg", notes:"Bedtime, fasted; personal preference is to use separately from CJC/IPA.",
      currentStep:0,
      steps:[
        {label:"First 7 nights",dose:1,units:20,guidance:"Nightly"},
        {label:"Night 8 onward",dose:2,units:40,guidance:"Nightly"}
      ]
    },
    {
      id:"beast-motsc", profile:"Beast", name:"MOTS-C conservative ramp", item:"MOTS-C",
      vialMg:10, liquidMl:1, doseUnit:"mg", notes:"Morning preferred. Monday / Wednesday / Friday.",
      currentStep:0,
      steps:[
        {label:"Week 1",dose:1,units:10,guidance:"M/W/F"},
        {label:"Week 2",dose:2,units:20,guidance:"M/W/F"},
        {label:"Weeks 3–8",dose:5,units:50,guidance:"M/W/F"}
      ]
    },
    {
      id:"beast-klow", profile:"Beast", name:"KLOW daily ramp", item:"Klow 80 mg",
      vialMg:80, liquidMl:3, doseUnit:"units", notes:"Dose basis is GHK-Cu content. Rotate injection sites.",
      components:[{name:"GHK-Cu",mg:50},{name:"BPC-157",mg:10},{name:"TB-500",mg:10},{name:"KPV",mg:10}],
      currentStep:0,
      steps:[
        {label:"Week 1",dose:6,units:6,guidance:"Daily; delivers about 1 mg GHK-Cu and 200 mcg each BPC-157, TB-500, and KPV"},
        {label:"Weeks 2–8",dose:12,units:12,guidance:"Daily; delivers about 2 mg GHK-Cu and 400 mcg each BPC-157, TB-500, and KPV"}
      ]
    },
    {
      id:"beauty-cjcipa", profile:"Beauty", name:"CJC-1295 No DAC + Ipamorelin", item:"CJC-1295 (No DAC) + Ipamorelin",
      vialMg:10, liquidMl:2, doseUnit:"mcg", notes:"Personal cycle record. Fasted morning and bedtime.",
      components:[{name:"CJC-1295 No DAC",mg:5},{name:"Ipamorelin",mg:5}],
      currentStep:0,
      steps:[
        {label:"Morning",dose:250,units:5,guidance:"125 mcg + 125 mcg; fasted"},
        {label:"Bedtime",dose:250,units:5,guidance:"125 mcg + 125 mcg; fasted, ideally 2–3 hours after food"}
      ]
    }
  ],
  library: [
    {name:"CJC-1295 (No DAC) + Ipamorelin", category:"Blend", note:"5 mg + 5 mg reference entry."},
    {name:"Retatrutide / GLP-3R", category:"Research reference", note:"60 mg reference entry."},
    {name:"Tesamorelin", category:"Peptide", note:"10 mg reference entry."},
    {name:"MOTS-C", category:"Peptide", note:"10 mg reference entry."},
    {name:"Klow 80 mg", category:"Blend", note:"50 mg GHK-Cu + 10 mg BPC-157 + 10 mg TB-500 + 10 mg KPV."},
    {name:"KPV", category:"Peptide", note:"Reference name only."},
    {name:"BPC-157 + TB-500", category:"Blend", note:"Commonly called a Wolverine blend."},
    {name:"5-Amino-1MQ", category:"Research reference", note:"Reference name only."}
  ]
};

const FACTORY_PROTOCOLS = structuredClone(defaultData.protocols);
let data = loadData();
let deferredInstallPrompt = null;
function loadData(){
  try {
    const stored=JSON.parse(localStorage.getItem(STORAGE_KEY) || "{}");
    const merged={...structuredClone(defaultData),...stored};
    const storedProtocols=Array.isArray(stored.protocols)?stored.protocols:[];
    const byId=new Map(storedProtocols.map(p=>[p.id,p]));
    merged.protocols=[
      ...defaultData.protocols.map(factory=>{
        const saved=byId.get(factory.id);
        byId.delete(factory.id);
        return saved
          ? {...structuredClone(factory),...saved,steps:Array.isArray(saved.steps)&&saved.steps.length?saved.steps:structuredClone(factory.steps),currentStep:Number.isInteger(saved.currentStep)?saved.currentStep:0}
          : structuredClone(factory);
      }),
      ...[...byId.values()]
    ];
    merged.vials=(stored.vials||[]).map(v=>({...v,typicalDose:v.typicalDose??"",typicalDoseUnit:v.typicalDoseUnit||"mg",opened:v.opened||"",lowAt:v.lowAt??""}));
    merged.reminders=(stored.reminders||[]).map(r=>({
      ...r,
      completed:Boolean(r.completed),
      completedAt:r.completedAt||"",
      completionCount:Number.isFinite(r.completionCount)?r.completionCount:0
    }));
    merged.history=stored.history||[];
    merged.activity=stored.activity||[];
    merged.onboardingComplete=Boolean(stored.onboardingComplete);
    merged.schemaVersion=DATA_SCHEMA_VERSION;
    return merged;
  } catch { return structuredClone(defaultData); }
}
function saveData(){ localStorage.setItem(STORAGE_KEY, JSON.stringify(data)); renderAll(); }
function uid(){ return crypto.randomUUID ? crypto.randomUUID() : String(Date.now()+Math.random()); }
function n(v){ return Number(v); }
function fmt(v, d=4){ return Number.isFinite(v) ? Number(v.toFixed(d)).toLocaleString(undefined,{maximumFractionDigits:d}) : "—"; }
function toast(msg){ const t=$("#toast"); t.textContent=msg; t.classList.add("show"); setTimeout(()=>t.classList.remove("show"),1800); }



function updateConnectionStatus(){
  const badge=$("#connectionBadge");
  if(!badge)return;
  const online=navigator.onLine;
  badge.textContent=online?"Online":"Offline";
  badge.classList.toggle("offline",!online);
}
window.addEventListener("online",()=>{updateConnectionStatus();toast("Back online")});
window.addEventListener("offline",()=>{updateConnectionStatus();toast("Offline mode")});

window.addEventListener("beforeinstallprompt",e=>{
  e.preventDefault();
  deferredInstallPrompt=e;
  updateInstallStatus();
  updateConnectionStatus();
  if(!data.onboardingComplete) setTimeout(()=>$("#onboardingDialog")?.showModal(),750);
});
window.addEventListener("appinstalled",()=>{
  deferredInstallPrompt=null;
  updateInstallStatus();
  toast("App installed");
});
function isStandalone(){
  return window.matchMedia("(display-mode: standalone)").matches || window.navigator.standalone===true;
}
function updateInstallStatus(){
  const btn=$("#installAppBtn"), status=$("#installStatus");
  if(!btn||!status)return;
  if(isStandalone()){
    btn.disabled=true;
    btn.textContent="Installed";
    status.textContent="The app is installed on this device.";
    status.classList.add("install-ready");
  }else if(deferredInstallPrompt){
    btn.disabled=false;
    btn.textContent="Install app";
    status.textContent="Ready to install.";
    status.classList.add("install-ready");
  }else{
    btn.disabled=false;
    btn.textContent="Installation help";
    status.textContent="In Chrome, open the menu and choose Add to Home screen or Install app.";
    status.classList.remove("install-ready");
  }
}

window.addEventListener("load", ()=>{
  document.documentElement.dataset.theme=data.theme;
  setTimeout(()=>$("#splash").classList.add("hide"),650);
  renderAll();
  checkReminders();
  setInterval(checkReminders, 60000);
  addBlendRow("Component 1", "");
  addBlendRow("Component 2", "");
  if("serviceWorker" in navigator) navigator.serviceWorker.register("sw.js").then(reg=>{
    if(reg.waiting) toast("An app update is ready. Reopen the app to use it.");
    reg.addEventListener("updatefound",()=>{
      const worker=reg.installing;
      worker?.addEventListener("statechange",()=>{
        if(worker.state==="installed"&&navigator.serviceWorker.controller) toast("App update downloaded. Reopen to finish.");
      });
    });
  }).catch(()=>{});
  updateInstallStatus();
  updateConnectionStatus();
  if(!data.onboardingComplete) setTimeout(()=>$("#onboardingDialog")?.showModal(),750);
});

$$(".tab").forEach(btn=>btn.addEventListener("click",()=>showView(btn.dataset.view)));
$$("[data-jump]").forEach(btn=>btn.addEventListener("click",()=>showView(btn.dataset.jump)));
function showView(id){
  $$(".tab").forEach(x=>x.classList.toggle("active",x.dataset.view===id));
  $$(".view").forEach(x=>x.classList.toggle("active",x.id===id));
  if(id==="home") renderDashboard();
  window.scrollTo({top:0,behavior:"smooth"});
}


let onboardingStep=0;
function renderOnboarding(){
  $$(".onboarding-step").forEach((el,i)=>el.classList.toggle("active",i===onboardingStep));
  $("#onboardingBack").classList.toggle("hidden",onboardingStep===0);
  $("#onboardingNext").textContent=onboardingStep===2?"Open dashboard":"Continue";
}
$$("[data-onboarding-profile]").forEach(btn=>btn.addEventListener("click",()=>{
  data.activeProfile=btn.dataset.onboardingProfile;
  $$("[data-onboarding-profile]").forEach(x=>x.classList.toggle("active",x.dataset.onboardingProfile===data.activeProfile));
}));
$("#onboardingBack").addEventListener("click",()=>{onboardingStep=Math.max(0,onboardingStep-1);renderOnboarding()});
$("#onboardingNext").addEventListener("click",()=>{
  if(onboardingStep<2){onboardingStep++;renderOnboarding();return}
  data.onboardingComplete=true;
  $("#onboardingDialog").close();
  saveData();
  toast("Dashboard ready");
});

$$(".profile-btn").forEach(btn=>btn.addEventListener("click",()=>{
  data.activeProfile=btn.dataset.profile;
  $$(".profile-btn").forEach(x=>x.classList.toggle("active",x.dataset.profile===data.activeProfile));
  saveData();
}));

$("#themeBtn").addEventListener("click",()=>{
  data.theme = data.theme==="dark" ? "light" : "dark";
  document.documentElement.dataset.theme=data.theme; saveData();
});

$("#calcMode").addEventListener("change",e=>{
  $$(".calc-panel").forEach(x=>x.classList.add("hidden"));
  $("#"+e.target.value+"Panel").classList.remove("hidden");
});

["doseVialMg","doseMl","doseDesired","doseUnit","syringeSize"].forEach(id=>$("#"+id).addEventListener("input",calcDose));
function calcDose(){
  const vial=n($("#doseVialMg").value), ml=n($("#doseMl").value), desiredRaw=n($("#doseDesired").value);
  const syringe=n($("#syringeSize").value), unit=$("#doseUnit").value, warning=$("#doseWarning");
  warning.classList.add("hidden"); warning.textContent="";
  if(!(vial>0&&ml>0&&desiredRaw>=0)){
    $("#doseResult").textContent="—"; $("#doseSub").textContent="Enter your vial and dose information.";
    $("#doseMath").textContent="No calculation yet."; return;
  }
  const desiredMg=unit==="mcg"?desiredRaw/1000:desiredRaw;
  const mgPerMl=vial/ml, mlNeeded=desiredMg/mgPerMl, units=mlNeeded*syringe, mcgPerUnit=(mgPerMl*1000)/syringe;
  if(units>syringe){
    warning.textContent=`This result is ${fmt(units,3)} units, which exceeds the selected syringe capacity of ${syringe} units. Recheck the vial amount, liquid volume, desired dose, and syringe type.`;
    warning.classList.remove("hidden");
  }else if(units>90){
    warning.textContent="This result is close to the full capacity of the selected syringe. Recheck all entered values before relying on it.";
    warning.classList.remove("hidden");
  }
  $("#doseResult").textContent=`${fmt(units,3)} syringe units`;
  $("#doseSub").textContent=`${fmt(mlNeeded,4)} mL · ${fmt(mgPerMl,4)} mg/mL`;
  $("#doseMath").textContent=[
    `1) Concentration = ${vial} mg ÷ ${ml} mL = ${fmt(mgPerMl,6)} mg/mL`,
    `2) Desired dose = ${fmt(desiredMg,6)} mg`,
    `3) Volume needed = ${fmt(desiredMg,6)} mg ÷ ${fmt(mgPerMl,6)} mg/mL = ${fmt(mlNeeded,6)} mL`,
    `4) Syringe units = ${fmt(mlNeeded,6)} mL × ${syringe} units/mL = ${fmt(units,4)} units`,
    `5) Each syringe unit contains about ${fmt(mcgPerUnit,4)} mcg`
  ].join("\n");
}

$("#copyDose").addEventListener("click",async()=>{
  if($("#doseResult").textContent==="—")return toast("Calculate a result first");
  const text=[$("#doseLabel").value.trim()||"Dose calculation",$("#doseResult").textContent,$("#doseSub").textContent,$("#doseMath").textContent].join("\n");
  try{
    await navigator.clipboard.writeText(text);
    $("#copyDose").classList.add("copy-success");
    toast("Result copied");
    setTimeout(()=>$("#copyDose").classList.remove("copy-success"),1000);
  }catch{
    toast("Copy was not available in this browser");
  }
});


$("#recordCalculatedDose").addEventListener("click",()=>{
  calcDose();
  if($("#doseResult").textContent==="—")return toast("Calculate a valid result first");
  const unitsMatch=$("#doseResult").textContent.match(/([\d,.]+)\s+syringe units/i);
  const units=unitsMatch?Number(unitsMatch[1].replaceAll(",","")):NaN;
  const label=$("#doseLabel").value.trim()||"Manual calculator entry";
  const vialMg=n($("#doseVialMg").value),liquidMl=n($("#doseMl").value);
  const desired=n($("#doseDesired").value),doseUnit=$("#doseUnit").value;
  const possible=data.vials.find(v=>v.name.toLowerCase()===label.toLowerCase()) ||
    data.vials.find(v=>label.toLowerCase().includes(v.name.toLowerCase()));
  const usedMg=doseUnit==="mcg"?desired/1000:desired;
  const previousRemaining=possible?Number(possible.remaining):null;
  let inventoryNote="No matching tracked vial was changed.";
  if(possible&&Number.isFinite(usedMg)&&usedMg>0){
    possible.remaining=Math.max(0,n(possible.remaining)-usedMg);
    inventoryNote=`${fmt(usedMg,5)} mg removed from ${possible.name}. ${fmt(possible.remaining,5)} mg remains.`;
  }
  data.activity.unshift({
    id:uid(),profile:data.activeProfile,protocol:"Manual calculator",item:label,step:"Calculated dose",
    units:Number.isFinite(units)?units:0,dose:desired,doseUnit,usedMg:Number.isFinite(usedMg)?usedMg:null,
    vialId:possible?.id||"",previousRemaining,inventoryNote,created:new Date().toISOString()
  });
  saveData();
  toast(possible?"Dose recorded and vial updated":"Dose recorded");
});

$("#saveDose").addEventListener("click",()=>{
  calcDose();
  if($("#doseResult").textContent==="—") return toast("Enter valid values first");
  data.history.unshift({
    id:uid(), type:"Dose calculation", label:$("#doseLabel").value.trim()||"Untitled",
    result:$("#doseResult").textContent, details:$("#doseSub").textContent,
    math:$("#doseMath").textContent, created:new Date().toISOString()
  });
  saveData(); toast("Calculation saved");
});

["recVialMg","recMl"].forEach(id=>$("#"+id).addEventListener("input",calcRec));
function calcRec(){
  const vial=n($("#recVialMg").value), ml=n($("#recMl").value);
  if(!(vial>0&&ml>0)){ $("#recResult").textContent="—"; return; }
  const mgml=vial/ml, mcgUnit=mgml*10;
  $("#recResult").textContent=`${fmt(mgml,5)} mg/mL`;
  $("#recSub").textContent=`${fmt(mcgUnit,4)} mcg per U-100 syringe unit`;
  $("#recMath").textContent=`${vial} mg ÷ ${ml} mL = ${fmt(mgml,6)} mg/mL\n${fmt(mgml,6)} mg/mL × 1000 mcg/mg ÷ 100 units/mL = ${fmt(mcgUnit,6)} mcg per unit`;
}

function addBlendRow(name="", amount=""){
  const row=document.createElement("div"); row.className="blend-row";
  row.innerHTML=`<input class="blend-name" placeholder="Component name" value="${name}">
    <input class="blend-amount" type="number" min="0" step="any" placeholder="mg in vial" value="${amount}">
    <button type="button" aria-label="Remove component">Remove</button>`;
  row.querySelector("button").onclick=()=>{row.remove();calcBlend()};
  row.querySelectorAll("input").forEach(i=>i.addEventListener("input",calcBlend));
  $("#blendRows").append(row);
}
$("#addBlendRow").addEventListener("click",()=>addBlendRow());
["blendMl","blendUnits","blendSyringe"].forEach(id=>$("#"+id).addEventListener("input",calcBlend));
function calcBlend(){
  const ml=n($("#blendMl").value), drawUnits=n($("#blendUnits").value), syringe=n($("#blendSyringe").value);
  const rows=$$(".blend-row").map(r=>({name:$(".blend-name",r).value||"Component",mg:n($(".blend-amount",r).value)}));
  if(!(ml>0&&drawUnits>=0&&rows.some(r=>r.mg>0))){$("#blendResults").innerHTML="";$("#blendMath").textContent="No calculation yet.";return}
  const drawMl=drawUnits/syringe;
  $("#blendResults").innerHTML=rows.filter(r=>r.mg>0).map(r=>{
    const perMl=r.mg/ml, delivered=perMl*drawMl;
    return `<div class="result-row"><span>${esc(r.name)}</span><strong>${fmt(delivered,5)} mg (${fmt(delivered*1000,3)} mcg)</strong></div>`;
  }).join("");
  $("#blendMath").textContent=`Volume drawn = ${drawUnits} units ÷ ${syringe} units/mL = ${fmt(drawMl,6)} mL\n\n`+
    rows.filter(r=>r.mg>0).map(r=>`${r.name}: ${r.mg} mg ÷ ${ml} mL × ${fmt(drawMl,6)} mL = ${fmt((r.mg/ml)*drawMl,6)} mg`).join("\n");
}

["convertValue","convertFrom","convertTo"].forEach(id=>$("#"+id).addEventListener("input",calcConvert));
function calcConvert(){
  const v=n($("#convertValue").value), from=$("#convertFrom").value, to=$("#convertTo").value;
  const mass={g:1000,mg:1,mcg:.001}, vol={ml:1,ul:.001};
  let out=NaN;
  if(from in mass && to in mass) out=v*mass[from]/mass[to];
  if(from in vol && to in vol) out=v*vol[from]/vol[to];
  $("#convertResult").textContent=Number.isFinite(out)?`${fmt(out,6)} ${to}`:"Incompatible units";
}



function refreshScheduleProtocolOptions(){
  const profile=$("#scheduleProfile").value;
  const items=data.protocols.filter(p=>p.profile===profile);
  $("#scheduleProtocol").innerHTML=items.map(p=>`<option value="${p.id}">${esc(p.name)}</option>`).join("");
}
$("#buildProtocolSchedule").addEventListener("click",()=>{
  $("#scheduleProfile").value=data.activeProfile;
  $("#scheduleStartDate").value=new Date().toISOString().slice(0,10);
  refreshScheduleProtocolOptions();
  $("#scheduleDialog").showModal();
});
$("#scheduleProfile").addEventListener("change",refreshScheduleProtocolOptions);
function addDays(date,days){const d=new Date(date);d.setDate(d.getDate()+days);return d}
function nextMwf(date){
  const d=new Date(date);
  do{d.setDate(d.getDate()+1)}while(![1,3,5].includes(d.getDay()));
  return d;
}
$("#createScheduleBtn").addEventListener("click",e=>{
  e.preventDefault();
  const p=data.protocols.find(x=>x.id===$("#scheduleProtocol").value);
  if(!p)return toast("Choose a protocol");
  let current=new Date(`${$("#scheduleStartDate").value}T${$("#scheduleTime").value}:00`);
  const count=Math.max(1,Math.min(60,n($("#scheduleCount").value)||1));
  const freq=$("#scheduleFrequency").value;
  for(let i=0;i<count;i++){
    const step=p.steps?.[Math.min(i,p.steps.length-1)]||p.steps?.[p.currentStep||0]||{};
    data.reminders.push({
      id:uid(),profile:p.profile,title:`${p.item}${step.label?` — ${step.label}`:""}`,
      date:current.toISOString().slice(0,10),time:current.toTimeString().slice(0,5),
      repeat:"none",notes:step.guidance||p.notes||"",lastFired:"",completed:false,completedAt:"",completionCount:0
    });
    if(freq==="daily") current=addDays(current,1);
    else if(freq==="weekly") current=addDays(current,7);
    else if(freq==="mwf") current=nextMwf(current);
    else if(freq==="twice-daily"){
      if(i%2===0) current=new Date(current.getFullYear(),current.getMonth(),current.getDate(),20,0,0);
      else current=new Date(current.getFullYear(),current.getMonth(),current.getDate()+1,8,0,0);
    }
  }
  $("#scheduleDialog").close();
  saveData();
  toast(`${count} reminders created`);
  showView("reminders");
});

$("#protocolReminderBuilder").addEventListener("click",()=>{
  const items=data.protocols.filter(p=>p.profile===data.activeProfile);
  if(!items.length)return toast("No protocols available for this profile");
  const p=items[0],s=p.steps?.[p.currentStep||0];
  $("#reminderProfile").value=p.profile;
  $("#reminderTitle").value=`${p.item}${s?` — ${s.label}`:""}`;
  $("#reminderDate").value=new Date().toISOString().slice(0,10);
  $("#reminderTime").value="08:00";
  $("#reminderNotes").value=s?.guidance||p.notes||"";
  showView("reminders");
  toast("Reminder details prepared");
});



$("#exportProtocols").addEventListener("click",()=>{
  const payload={
    app:"Beauty & Beast Wellness",
    version:"1.9",
    exported:new Date().toISOString(),
    protocols:data.protocols
  };
  downloadText(`beauty-beast-protocols-${new Date().toISOString().slice(0,10)}.json`,JSON.stringify(payload,null,2),"application/json");
  toast("Protocols exported");
});
$("#importProtocols").addEventListener("change",async e=>{
  const file=e.target.files[0];
  createSnapshot("Before protocol import");
  if(!file)return;
  try{
    const parsed=JSON.parse(await file.text());
    const incoming=Array.isArray(parsed)?parsed:parsed.protocols;
    if(!Array.isArray(incoming))throw new Error("No protocol list");
    const existingIds=new Set(data.protocols.map(p=>p.id));
    incoming.forEach(p=>{
      const clean={...p,id:p.id||uid(),profile:p.profile||data.activeProfile,currentStep:Number.isInteger(p.currentStep)?p.currentStep:0};
      const i=data.protocols.findIndex(x=>x.id===clean.id);
      if(i>=0)data.protocols[i]=clean;else data.protocols.push(clean);
    });
    saveData();
    toast(`${incoming.length} protocol${incoming.length===1?"":"s"} imported`);
  }catch{
    toast("That protocol file could not be imported");
  }
  e.target.value="";
});

$("#printProtocols").addEventListener("click",()=>{
  $("#printGeneratedDate").textContent=`Generated ${new Date().toLocaleString()}`;
  $("#printProtocolContent").innerHTML=["Beast","Beauty"].map(profile=>{
    const items=data.protocols.filter(p=>p.profile===profile);
    return `<h2>${profile}</h2>${items.map(p=>`<h3>${esc(p.name)}</h3><p>${esc(p.item)} · ${fmt(p.vialMg||0,4)} mg vial · ${fmt(p.liquidMl||0,4)} mL</p><table><thead><tr><th>Step</th><th>Dose</th><th>Units</th><th>Guidance</th></tr></thead><tbody>${(p.steps||[]).map(s=>`<tr><td>${esc(s.label)}</td><td>${fmt(s.dose,4)} ${esc(p.doseUnit)}</td><td>${fmt(s.units,4)}</td><td>${esc(s.guidance||"")}</td></tr>`).join("")}</tbody></table>`).join("")||"<p>No protocols saved.</p>"}`;
  }).join("");
  window.print();
});

$("#addProtocol").onclick=()=>openProtocol();
function openProtocol(p={}){
  const current=Math.min(Math.max(p.currentStep||0,0),Math.max((p.steps||[]).length-1,0));
  const step=p.steps?.[current]||{};
  $("#protocolId").value=p.id||"";
  $("#protocolProfile").value=p.profile||data.activeProfile||"Beast";
  $("#protocolName").value=p.name||"";
  $("#protocolItem").value=p.item||"";
  $("#protocolVialMg").value=p.vialMg??"";
  $("#protocolLiquidMl").value=p.liquidMl??"";
  $("#protocolStepLabel").value=step.label||"";
  $("#protocolDose").value=step.dose??p.dose??"";
  $("#protocolDoseUnit").value=p.doseUnit||"mg";
  $("#protocolUnits").value=step.units??"";
  $("#protocolGuidance").value=step.guidance||"";
  $("#protocolNotes").value=p.notes||"";
  $("#protocolDialog").showModal();
}
function protocolUnitsFromInputs(vialMg,liquidMl,dose,doseUnit){
  if(!(vialMg>0&&liquidMl>0&&dose>=0))return NaN;
  if(doseUnit==="units")return dose;
  const doseMg=doseUnit==="mcg"?dose/1000:dose;
  return (doseMg/(vialMg/liquidMl))*100;
}
$("#saveProtocolBtn").addEventListener("click",e=>{
  e.preventDefault();
  const id=$("#protocolId").value||uid();
  const name=$("#protocolName").value.trim(), item=$("#protocolItem").value.trim();
  if(!name||!item) return toast("Name and item are required");
  const existing=data.protocols.find(x=>x.id===id);
  const vialMg=$("#protocolVialMg").value===""?(existing?.vialMg??""):n($("#protocolVialMg").value);
  const liquidMl=$("#protocolLiquidMl").value===""?(existing?.liquidMl??""):n($("#protocolLiquidMl").value);
  const dose=$("#protocolDose").value===""?"":n($("#protocolDose").value);
  const doseUnit=$("#protocolDoseUnit").value;
  let units=$("#protocolUnits").value===""?NaN:n($("#protocolUnits").value);
  if(!Number.isFinite(units)&&dose!=="") units=protocolUnitsFromInputs(n(vialMg),n(liquidMl),dose,doseUnit);
  const step={
    label:$("#protocolStepLabel").value.trim()||existing?.steps?.[existing.currentStep||0]?.label||"Custom step",
    dose:dose===""?0:dose,
    units:Number.isFinite(units)?units:0,
    guidance:$("#protocolGuidance").value.trim()
  };
  let steps=structuredClone(existing?.steps||[]);
  const current=Number.isInteger(existing?.currentStep)?existing.currentStep:0;
  if(steps.length)steps[Math.min(current,steps.length-1)]=step;else steps=[step];
  const p={
    ...(existing||{}),id,profile:$("#protocolProfile").value,name,item,
    vialMg:vialMg===""?0:n(vialMg),liquidMl:liquidMl===""?0:n(liquidMl),
    doseUnit,notes:$("#protocolNotes").value.trim(),steps,currentStep:Math.min(current,steps.length-1)
  };
  const i=data.protocols.findIndex(x=>x.id===id);
  if(i>=0)data.protocols[i]=p;else data.protocols.unshift(p);
  $("#protocolDialog").close();
  saveData();
  toast(existing?"Protocol updated without losing its other steps":"Protocol created");
});


function updateVialPreview(){
  const amount=n($("#vialAmount").value), remaining=$("#vialRemaining").value===""?amount:n($("#vialRemaining").value);
  const adjustment=$("#vialAdjustment").value===""?0:n($("#vialAdjustment").value);
  const finalValue=Math.max(0,remaining+adjustment);
  const preview=$("#vialPreview");
  if(!preview)return;
  if(!(amount>0)){preview.textContent="Enter the vial amount to preview inventory.";return}
  preview.textContent=`After saving: ${fmt(finalValue,4)} mg remaining (${fmt((finalValue/amount)*100,1)}% of the original vial).`;
}
["vialAmount","vialRemaining","vialAdjustment"].forEach(id=>$("#"+id).addEventListener("input",updateVialPreview));

$("#addVial").onclick=()=>openVial();
function openVial(v={}){
  $("#vialId").value=v.id||""; $("#vialName").value=v.name||""; $("#vialAmount").value=v.amount??"";
  $("#vialLiquid").value=v.liquid??""; $("#vialRemaining").value=v.remaining??"";
  $("#vialTypicalDose").value=v.typicalDose??""; $("#vialTypicalDoseUnit").value=v.typicalDoseUnit||"mg";
  $("#vialOpened").value=v.opened||""; $("#vialLowAt").value=v.lowAt??""; $("#vialAdjustment").value="";
  $("#vialShared").value=v.shared||"Beast & Beauty"; $("#vialNotes").value=v.notes||""; updateVialPreview(); $("#vialDialog").showModal();
}
$("#saveVialBtn").addEventListener("click",e=>{
  e.preventDefault();
  const name=$("#vialName").value.trim(),amount=n($("#vialAmount").value),liquid=n($("#vialLiquid").value);
  if(!name||!(amount>0)||!(liquid>0)) return toast("Name, amount, and liquid are required");
  const existing=data.vials.find(x=>x.id===$("#vialId").value);
  let remaining=$("#vialRemaining").value===""?(existing?.remaining??amount):n($("#vialRemaining").value);
  const adjustment=$("#vialAdjustment").value===""?0:n($("#vialAdjustment").value);
  remaining=Math.max(0,remaining+adjustment);
  const v={id:$("#vialId").value||uid(),name,amount,liquid,remaining,typicalDose:$("#vialTypicalDose").value===""?"":n($("#vialTypicalDose").value),typicalDoseUnit:$("#vialTypicalDoseUnit").value,opened:$("#vialOpened").value,lowAt:$("#vialLowAt").value===""?"":n($("#vialLowAt").value),shared:$("#vialShared").value,notes:$("#vialNotes").value.trim()};
  const i=data.vials.findIndex(x=>x.id===v.id); if(i>=0)data.vials[i]=v;else data.vials.unshift(v);
  $("#vialDialog").close();saveData();toast("Vial saved");
});

$("#librarySearch").addEventListener("input",renderLibrary);


function downloadText(filename,text,type="text/plain"){
  const blob=new Blob([text],{type});
  const a=document.createElement("a");
  a.href=URL.createObjectURL(blob);a.download=filename;a.click();URL.revokeObjectURL(a.href);
}
function csvCell(v){
  const s=String(v??"");
  return `"${s.replaceAll('"','""')}"`;
}
$("#exportActivityCsv").addEventListener("click",()=>{
  const rows=[["Date","Profile","Item","Protocol","Step","Syringe Units","Inventory Change"]];
  data.activity.forEach(a=>rows.push([new Date(a.created).toLocaleString(),a.profile,a.item,a.protocol,a.step,a.units,a.inventoryNote]));
  downloadText("beauty-beast-activity.csv",rows.map(r=>r.map(csvCell).join(",")).join("\n"),"text/csv");
  toast("Activity CSV exported");
});
$("#exportHistoryCsv").addEventListener("click",()=>{
  const rows=[["Date","Label","Result","Details"]];
  data.history.forEach(h=>rows.push([new Date(h.created).toLocaleString(),h.label,h.result,h.details]));
  downloadText("beauty-beast-calculation-history.csv",rows.map(r=>r.map(csvCell).join(",")).join("\n"),"text/csv");
  toast("History CSV exported");
});

$("#activityProfileFilter").addEventListener("change",renderActivity);

$("#undoLastDose").addEventListener("click",()=>{
  const last=data.activity[0];
  if(!last)return toast("There is no recorded dose to undo");
  if(!confirm(`Undo the most recent recorded dose: ${last.item} — ${last.step}?`))return;
  if(last.vialId&&Number.isFinite(last.previousRemaining)){
    const vial=data.vials.find(v=>v.id===last.vialId);
    if(vial)vial.remaining=last.previousRemaining;
  }
  data.activity.shift();
  saveData();
  $("#undoLastDose").classList.add("undo-highlight");
  setTimeout(()=>$("#undoLastDose").classList.remove("undo-highlight"),900);
  toast("Last recorded dose undone");
});

$("#clearActivity").addEventListener("click",()=>{
  if(confirm("Clear the activity log? This will not restore vial inventory.")){
    data.activity=[];
    saveData();
  }
});
$("#installAppBtn").addEventListener("click",async()=>{
  if(isStandalone())return;
  if(deferredInstallPrompt){
    deferredInstallPrompt.prompt();
    await deferredInstallPrompt.userChoice;
    deferredInstallPrompt=null;
    updateInstallStatus();
  }else{
    alert("In Chrome, tap the three-dot menu, then choose Add to Home screen or Install app.");
  }
});
function renderSettings(){
  const theme=$("#settingsTheme");
  if(theme)theme.value=data.theme;
  updateInstallStatus();
  updateSnapshotStatus();
}
$("#settingsTheme").addEventListener("change",e=>{
  data.theme=e.target.value;
  document.documentElement.dataset.theme=data.theme;
  saveData();
});
function exportBackup(){
  data.schemaVersion=DATA_SCHEMA_VERSION;
  const blob=new Blob([JSON.stringify(data,null,2)],{type:"application/json"});
  const a=document.createElement("a");
  a.href=URL.createObjectURL(blob);
  a.download=`beauty-beast-wellness-backup-${new Date().toISOString().slice(0,10)}.json`;
  a.click();
  URL.revokeObjectURL(a.href);
}
async function importBackupFile(file){
  if(!file)return;
  createSnapshot("Before full backup import");
  try{
    const imported=JSON.parse(await file.text());
    if(typeof imported!=="object"||Array.isArray(imported))throw new Error("Invalid backup");
    const requiredArrays=["protocols","vials","reminders","history","activity"];
    requiredArrays.forEach(key=>{
      if(imported[key]!==undefined&&!Array.isArray(imported[key]))throw new Error(`Invalid ${key}`);
    });
    data={...structuredClone(defaultData),...imported,schemaVersion:DATA_SCHEMA_VERSION};
    saveData();
    toast("Backup imported");
  }catch{
    toast("That backup file could not be read safely");
  }
}
$("#settingsExport").addEventListener("click",exportBackup);
$("#settingsImport").addEventListener("change",async e=>{
  await importBackupFile(e.target.files[0]);
  e.target.value="";
});




function createSnapshot(reason="Manual snapshot"){
  const payload={
    created:new Date().toISOString(),
    reason,
    schemaVersion:DATA_SCHEMA_VERSION,
    data:structuredClone(data)
  };
  localStorage.setItem(SNAPSHOT_KEY,JSON.stringify(payload));
  updateSnapshotStatus();
  return payload;
}
function readSnapshot(){
  try{return JSON.parse(localStorage.getItem(SNAPSHOT_KEY)||"null")}catch{return null}
}
function updateSnapshotStatus(){
  const el=$("#snapshotStatus");
  if(!el)return;
  const snap=readSnapshot();
  el.textContent=snap?`Last snapshot: ${new Date(snap.created).toLocaleString()} · ${snap.reason}`:"No safety snapshot exists yet.";
}
$("#createSafetySnapshot").addEventListener("click",()=>{
  createSnapshot("Manual snapshot");
  toast("Safety snapshot created");
});
$("#restoreSafetySnapshot").addEventListener("click",()=>{
  const snap=readSnapshot();
  if(!snap?.data)return toast("No safety snapshot is available");
  if(!confirm(`Restore the snapshot from ${new Date(snap.created).toLocaleString()}? Current app data will be replaced.`))return;
  data={...structuredClone(defaultData),...snap.data,schemaVersion:DATA_SCHEMA_VERSION};
  saveData();
  toast("Safety snapshot restored");
});

$("#checkStorage").addEventListener("click",async()=>{
  const el=$("#storageResults");
  try{
    let text="Browser storage estimate is not available.";
    if(navigator.storage?.estimate){
      const {usage=0,quota=0}=await navigator.storage.estimate();
      const mb=x=>(x/1024/1024).toFixed(2);
      const pct=quota?((usage/quota)*100).toFixed(2):"0";
      text=`Using ${mb(usage)} MB of ${mb(quota)} MB (${pct}%).`;
    }
    const localBytes=new Blob([localStorage.getItem(STORAGE_KEY)||""]).size;
    el.innerHTML=`<div class="mini-item test-pass"><div><strong>Storage available</strong><small>${esc(text)} App data itself is ${(localBytes/1024).toFixed(1)} KB.</small></div></div>`;
    toast("Storage checked");
  }catch{
    el.innerHTML='<div class="mini-item test-warn"><div><strong>Storage estimate unavailable</strong><small>The browser did not provide storage details.</small></div></div>';
  }
});

$("#runDataCheck").addEventListener("click",()=>{
  const issues=[];
  data.protocols.forEach(p=>{
    if(!(p.vialMg>0))issues.push(`${p.profile}: ${p.name} has no valid vial amount.`);
    if(!(p.liquidMl>0))issues.push(`${p.profile}: ${p.name} has no valid liquid volume.`);
    if(!Array.isArray(p.steps)||!p.steps.length)issues.push(`${p.profile}: ${p.name} has no protocol steps.`);
    (p.steps||[]).forEach(s=>{
      if(!(s.units>=0))issues.push(`${p.profile}: ${p.name} — ${s.label} has invalid syringe units.`);
    });
  });
  data.vials.forEach(v=>{
    if(!(v.amount>0))issues.push(`${v.name} has an invalid starting amount.`);
    if(!(v.liquid>0))issues.push(`${v.name} has an invalid liquid volume.`);
    if(v.remaining<0)issues.push(`${v.name} has negative remaining inventory.`);
    if(v.remaining>v.amount)issues.push(`${v.name} has more remaining than its original amount.`);
  });
  data.reminders.forEach(r=>{
    if(!r.date||!r.time)issues.push(`${r.title||"A reminder"} is missing a date or time.`);
  });
  const el=$("#dataCheckResults");
  if(!issues.length){
    el.innerHTML='<div class="mini-item audit-ok"><div><strong>No problems found</strong><small>Protocols, vials, and reminders passed the basic data check.</small></div></div>';
    toast("Data check passed");
  }else{
    el.innerHTML=issues.map(x=>`<div class="mini-item audit-warning"><div><strong>Review needed</strong><small>${esc(x)}</small></div></div>`).join("");
    toast(`${issues.length} item${issues.length===1?"":"s"} need review`);
  }
});



$("#runReleaseCheck").addEventListener("click",async()=>{
  const checks=[];
  const add=(status,title,detail)=>checks.push({status,title,detail});
  add("pass","Core files","App shell, calculator, protocols, vials, reminders, activity, and settings are present.");
  add(Array.isArray(data.protocols)&&data.protocols.length>0?"pass":"fail","Protocols",`${data.protocols.length} protocol records available.`);
  add(data.protocols.every(p=>Array.isArray(p.steps)&&p.steps.length)?"pass":"fail","Protocol steps","Every protocol has at least one step.");
  add(data.protocols.every(p=>p.vialMg>0&&p.liquidMl>0)?"pass":"note","Protocol math inputs","All preloaded protocols should have a vial amount and liquid volume.");
  add("serviceWorker" in navigator?"pass":"fail","Offline support","Service worker support detected.");
  add(Boolean(window.matchMedia("(display-mode: standalone)"))?"pass":"note","Install support","Installability depends on HTTPS hosting and browser support.");
  try{
    localStorage.setItem("bbw-release-test","ok");
    add(localStorage.getItem("bbw-release-test")==="ok"?"pass":"fail","Local storage","Read/write test completed.");
    localStorage.removeItem("bbw-release-test");
  }catch{add("fail","Local storage","Browser local storage is unavailable.");}
  add(navigator.onLine?"pass":"note","Connection","Currently online. Offline mode is supported after the first successful load.");
  const failures=checks.filter(c=>c.status==="fail").length;
  const notes=checks.filter(c=>c.status==="note").length;
  $("#releaseCheckResults").innerHTML=checks.map(c=>`<div class="mini-item ${c.status==="pass"?"release-ready":c.status==="fail"?"release-blocked":"release-note"}"><div><strong>${c.status==="pass"?"Ready":c.status==="fail"?"Blocked":"Review"}: ${esc(c.title)}</strong><small>${esc(c.detail)}</small></div></div>`).join("");
  toast(failures?`${failures} release blocker${failures===1?"":"s"} found`:notes?`Release check passed with ${notes} note${notes===1?"":"s"}`:"Release check passed");
});

$("#runSelfTest").addEventListener("click",()=>{
  const results=[];
  const add=(ok,name,detail)=>results.push({ok,name,detail});
  try{
    const vial=10,ml=2,dose=0.5;
    const units=(dose/(vial/ml))*100;
    add(Math.abs(units-10)<0.0001,"Dose calculator math",`Expected 10 units; calculated ${fmt(units,4)}.`);
  }catch(e){add(false,"Dose calculator math",String(e))}
  add(Array.isArray(data.protocols),"Protocol storage",`${data.protocols.length} protocol records found.`);
  add(Array.isArray(data.vials),"Vial storage",`${data.vials.length} vial records found.`);
  add(Array.isArray(data.reminders),"Reminder storage",`${data.reminders.length} reminders found.`);
  add(data.reminders.every(r=>typeof r.completed==="boolean"),"Reminder status","Completion status is valid for all reminders.");
  add(Array.isArray(data.activity),"Activity storage",`${data.activity.length} activity records found.`);
  add(Boolean($("#dashboardGreeting")),"Dashboard elements","Required dashboard element is present.");
  add("serviceWorker" in navigator,"Offline capability","Service worker support detected in this browser.");
  try{
    localStorage.setItem("bbw-self-test","ok");
    add(localStorage.getItem("bbw-self-test")==="ok","Local saving","Browser local storage is writable.");
    localStorage.removeItem("bbw-self-test");
  }catch{add(false,"Local saving","Browser local storage is not writable.");}
  const el=$("#selfTestResults");
  el.innerHTML=results.map(r=>`<div class="mini-item ${r.ok?"test-pass":"test-fail"}"><div><strong>${r.ok?"Pass":"Fail"}: ${esc(r.name)}</strong><small>${esc(r.detail)}</small></div></div>`).join("");
  const failures=results.filter(r=>!r.ok).length;
  toast(failures?`${failures} self-test failure${failures===1?"":"s"}`:"All self-tests passed");
});

$("#restoreFactoryProtocols").addEventListener("click",()=>{
  createSnapshot("Before restoring factory protocols");
  if(!confirm("Restore the original Beast and Beauty protocols? Custom protocols will remain, but original protocol records will be reset."))return;
  const factoryIds=new Set(FACTORY_PROTOCOLS.map(p=>p.id));
  const custom=data.protocols.filter(p=>!factoryIds.has(p.id));
  data.protocols=[...structuredClone(FACTORY_PROTOCOLS),...custom];
  saveData();
  toast("Original protocols restored");
});

$("#resetApp").addEventListener("click",()=>{
  createSnapshot("Before full app reset");
  if(confirm("Reset all protocols, vials, reminders, calculations, and activity on this device?")){
    localStorage.removeItem(STORAGE_KEY);
    data=structuredClone(defaultData);
    document.documentElement.dataset.theme=data.theme;
    saveData();
    toast("App data reset");
    onboardingStep=0;
    renderOnboarding();
    setTimeout(()=>$("#onboardingDialog")?.showModal(),250);
  }
});

$("#historySearch").addEventListener("input",renderHistory);
$("#clearHistory").onclick=()=>{if(confirm("Clear all saved calculations?")){data.history=[];saveData()}};

$("#exportBtn").onclick=exportBackup;
$("#importInput").addEventListener("change",async e=>{
  await importBackupFile(e.target.files[0]);
  e.target.value="";
});

function renderAll(){renderStats();renderProfiles();renderProtocols();renderVials();renderLibrary();renderReminders();renderActivity();renderHistory();renderDatalist();renderDashboard();renderSettings()}
function renderStats(){
  $("#savedCount").textContent=data.history.length;
  const vialCount=$("#vialCount"); if(vialCount) vialCount.textContent=data.vials.length;
  const protocolCount=$("#protocolCount"); if(protocolCount) protocolCount.textContent=data.protocols.length;
}
function renderProfiles(){
  $$(".profile-btn").forEach(x=>x.classList.toggle("active",x.dataset.profile===data.activeProfile));
}
function renderProtocols(){
  const items=data.protocols.filter(p=>p.profile===data.activeProfile);
  $("#protocolList").innerHTML=items.length?items.map(p=>{
    const current=Math.min(Math.max(p.currentStep||0,0),Math.max((p.steps||[]).length-1,0));
    const pct=(p.steps||[]).length?((current+1)/(p.steps.length))*100:0;
    return `<article class="item-card">
      <div>
        <span class="chip">${esc(p.profile)}</span>
        <span class="chip">${fmt(p.vialMg||0,4)} mg vial · ${fmt(p.liquidMl||0,4)} mL</span>
        <h3>${esc(p.name)}</h3><p>${esc(p.item)}</p>
        ${(p.steps||[]).length?`<p><strong>Current:</strong> ${esc(p.steps[current].label)} · ${fmt(p.steps[current].units,4)} units</p>
        <div class="progress-track"><div class="progress-fill" style="width:${pct}%"></div></div>`:""}
        <div class="protocol-steps">${(p.steps||[]).map((s,i)=>`<button class="step-btn ${i===current?"active":""}" onclick="setProtocolStep('${p.id}',${i})">${esc(s.label)} · ${fmt(s.units,4)} units</button>`).join("")}</div>
        ${p.notes?`<p>${esc(p.notes)}</p>`:""}
      </div>
      <div class="item-actions">
        <button class="record-btn" onclick="recordProtocolDose('${p.id}',${current})">Record dose</button>
        <button class="primary" onclick="loadProtocolStep('${p.id}',${current})">Calculate</button>
        <button class="secondary" onclick="editProtocol('${p.id}')">Edit</button>
        <button class="danger" onclick="deleteProtocol('${p.id}')">Delete</button>
      </div>
    </article>`;
  }).join(""):`<div class="card muted">No protocols saved for ${esc(data.activeProfile)}.</div>`;
}
function vialDoseMg(v){
  if(v.typicalDose===""||v.typicalDose==null)return NaN;
  if(v.typicalDoseUnit==="mg")return n(v.typicalDose);
  if(v.typicalDoseUnit==="mcg")return n(v.typicalDose)/1000;
  if(v.typicalDoseUnit==="units"){
    const mgPerMl=v.amount/v.liquid;
    return (n(v.typicalDose)/100)*mgPerMl;
  }
  return NaN;
}
function vialStatus(v){
  const lowAt=v.lowAt!==""&&v.lowAt!=null?n(v.lowAt):v.amount*.2;
  if(v.remaining<=0)return {label:"Empty",cls:"status-critical"};
  if(v.remaining<=lowAt)return {label:"Low",cls:"status-low"};
  return {label:"Good",cls:"status-good"};
}
function renderVials(){
  $("#vialList").innerHTML=data.vials.length?data.vials.map(v=>{
    const concentration=v.amount/v.liquid, doseMg=vialDoseMg(v);
    const doses=Number.isFinite(doseMg)&&doseMg>0?v.remaining/doseMg:NaN;
    const pct=Math.max(0,Math.min(100,(v.remaining/v.amount)*100));
    const status=vialStatus(v);
    return `<article class="item-card"><div>
      <span class="chip">${esc(v.shared)}</span><span class="chip">${status.label}</span><h3>${esc(v.name)}</h3>
      <p>${fmt(v.amount,4)} mg in ${fmt(v.liquid,4)} mL · ${fmt(concentration,4)} mg/mL</p>
      <div class="progress-track"><div class="progress-fill" style="width:${pct}%"></div></div>
      <div class="inventory-meta">
        <span class="chip">Remaining: ${fmt(v.remaining,4)} mg</span>
        ${Number.isFinite(doses)?`<span class="chip">About ${fmt(doses,1)} doses left</span>`:""}
        ${v.opened?`<span class="chip">Opened ${new Date(v.opened+"T12:00:00").toLocaleDateString()}</span>`:""}
      </div>
      ${v.notes?`<p>${esc(v.notes)}</p>`:""}</div>
      <div class="item-actions"><button class="secondary" onclick="useVial('${v.id}')">Use in calculator</button><button class="secondary" onclick="editVial('${v.id}')">Edit</button><button class="danger" onclick="deleteVial('${v.id}')">Delete</button></div></article>`;
  }).join(""):`<div class="card muted">No vials are being tracked yet.</div>`;
}
function renderLibrary(){
  const q=$("#librarySearch").value?.toLowerCase()||"";
  const items=data.library.filter(x=>(x.name+" "+x.category+" "+x.note).toLowerCase().includes(q));
  $("#libraryList").innerHTML=items.map(x=>`<article class="card library-card"><span class="chip">${esc(x.category)}</span><h3>${esc(x.name)}</h3><p>${esc(x.note)}</p></article>`).join("");
}

function matchingVialForProtocol(p){
  const exact=data.vials.find(v=>v.name.toLowerCase()===p.item.toLowerCase());
  if(exact)return exact;
  const key=p.item.toLowerCase().split(/[+/]/)[0].trim();
  return data.vials.find(v=>v.name.toLowerCase().includes(key)||key.includes(v.name.toLowerCase()));
}
function stepDoseMg(p,s,v){
  if(p.doseUnit==="mg")return n(s.dose);
  if(p.doseUnit==="mcg")return n(s.dose)/1000;
  if(p.doseUnit==="units"){
    const vial=v||matchingVialForProtocol(p);
    if(vial&&vial.amount>0&&vial.liquid>0)return (n(s.units)/100)*(vial.amount/vial.liquid);
    if(p.vialMg>0&&p.liquidMl>0)return (n(s.units)/100)*(p.vialMg/p.liquidMl);
  }
  return NaN;
}
window.recordProtocolDose=(id,stepIndex)=>{
  const p=data.protocols.find(x=>x.id===id),s=p?.steps?.[stepIndex];
  if(!p||!s)return;
  const vial=matchingVialForProtocol(p);
  const usedMg=stepDoseMg(p,s,vial);
  let inventoryNote="No matching tracked vial was changed.";
  const previousRemaining=vial?Number(vial.remaining):null;
  if(vial&&Number.isFinite(usedMg)&&usedMg>0){
    vial.remaining=Math.max(0,n(vial.remaining)-usedMg);
    inventoryNote=`${fmt(usedMg,5)} mg removed from ${vial.name}. ${fmt(vial.remaining,5)} mg remains.`;
  }
  data.activity.unshift({
    id:uid(),profile:p.profile,protocol:p.name,item:p.item,step:s.label,
    units:s.units,dose:s.dose,doseUnit:p.doseUnit,usedMg:Number.isFinite(usedMg)?usedMg:null,
    vialId:vial?.id||"",previousRemaining,inventoryNote,created:new Date().toISOString()
  });
  saveData();
  toast(vial?`Dose recorded and ${vial.name} updated`:"Dose recorded");
};

function startOfWeek(date=new Date()){
  const d=new Date(date);
  const day=d.getDay();
  const diff=(day===0?-6:1-day);
  d.setHours(0,0,0,0);
  d.setDate(d.getDate()+diff);
  return d;
}
function renderActivityStats(){
  renderActivityStats();
  const filter=$("#activityProfileFilter")?.value||"all";
  const weekStart=startOfWeek();
  const profileItems=filter==="all"?data.activity:data.activity.filter(a=>a.profile===filter);
  const thisWeek=data.activity.filter(a=>new Date(a.created)>=weekStart);
  $("#activityTotalCount").textContent=data.activity.length;
  $("#activityThisWeekCount").textContent=thisWeek.length;
  $("#activityProfileCount").textContent=profileItems.length;
}

function renderActivity(){
  const el=$("#activityList"); if(!el)return;
  const filter=$("#activityProfileFilter")?.value||"all";
  const items=filter==="all"?data.activity:data.activity.filter(a=>a.profile===filter);
  el.innerHTML=items.length?items.map(a=>`<article class="item-card">
    <div>
      <span class="chip">${esc(a.profile)}</span>
      <span class="chip">${new Date(a.created).toLocaleString()}</span>
      <h3>${esc(a.item)} — ${esc(a.step)}</h3>
      <p class="activity-dose">${fmt(a.units,4)} syringe units</p>
      <p>${esc(a.protocol)}</p>
      <p class="activity-reduction">${esc(a.inventoryNote)}</p>
    </div>
    <button class="danger" onclick="deleteActivity('${a.id}')">Delete log</button>
  </article>`).join(""):`<div class="card muted">No matching activity entries.</div>`;
}
window.deleteActivity=id=>{
  data.activity=data.activity.filter(x=>x.id!==id);
  saveData();
};

function renderHistory(){
  const q=($("#historySearch")?.value||"").trim().toLowerCase();
  const items=q?data.history.filter(h=>(`${h.label} ${h.result} ${h.details} ${h.math}`).toLowerCase().includes(q)):data.history;
  $("#historyList").innerHTML=items.length?items.map(h=>`<article class="item-card"><div><span class="chip">${new Date(h.created).toLocaleString()}</span><h3>${esc(h.label)}</h3><p>${esc(h.result)} · ${esc(h.details)}</p><details><summary>Show My Math</summary><pre>${esc(h.math)}</pre></details></div><button class="danger" onclick="deleteHistory('${h.id}')">Delete</button></article>`).join(""):`<div class="card muted">No matching saved calculations.</div>`;
}
function dueToday(r){
  const d=new Date(`${r.date}T${r.time}:00`);
  const now=new Date();
  return d.getFullYear()===now.getFullYear()&&d.getMonth()===now.getMonth()&&d.getDate()===now.getDate();
}
function renderDashboard(){
  const hour=new Date().getHours();
  const greeting=hour<12?"Good morning":hour<18?"Good afternoon":"Good evening";
  $("#dashboardGreeting").textContent=`${greeting}, ${data.activeProfile}`;
  const profileProtocols=data.protocols.filter(p=>p.profile===data.activeProfile);
  const today=data.reminders.filter(r=>!r.completed&&r.profile===data.activeProfile&&dueToday(r));
  const low=data.vials.filter(v=>["Low","Empty"].includes(vialStatus(v).label));
  $("#todayReminderCount").textContent=today.length;
  $("#activeProtocolCount").textContent=profileProtocols.length;
  $("#lowVialCount").textContent=low.length;
  $("#dashboardSummary").textContent=`${today.length} reminder${today.length===1?"":"s"} due today · ${profileProtocols.length} active protocol${profileProtocols.length===1?"":"s"} · ${low.length} low vial${low.length===1?"":"s"}`;

  $("#dashboardReminders").innerHTML=today.length?today.slice(0,4).map(r=>`<div class="mini-item"><div><strong>${esc(r.title)}</strong><small>${esc(r.time)} · ${esc(r.repeat)}</small></div><span class="status-dot"></span></div>`).join(""):`<div class="mini-item"><div><strong>No reminders due today</strong><small>Your schedule is clear.</small></div></div>`;

  $("#dashboardProtocols").innerHTML=profileProtocols.length?profileProtocols.slice(0,4).map(p=>{
    const i=Math.min(p.currentStep||0,Math.max((p.steps||[]).length-1,0)),s=p.steps?.[i];
    return `<button class="mini-item" onclick="loadProtocolStep('${p.id}',${i})"><div><strong>${esc(p.item)}</strong><small>${s?`${esc(s.label)} · ${fmt(s.units,4)} units`:"No step selected"}</small></div><span>Open</span></button>`;
  }).join(""):`<div class="mini-item"><div><strong>No protocols for ${esc(data.activeProfile)}</strong><small>Add one in My Protocols.</small></div></div>`;

  $("#dashboardVials").innerHTML=data.vials.length?data.vials.slice(0,4).map(v=>{
    const st=vialStatus(v),pct=Math.max(0,Math.min(100,(v.remaining/v.amount)*100));
    return `<div class="mini-item"><span class="status-dot ${st.cls}"></span><div style="flex:1"><strong>${esc(v.name)}</strong><small>${fmt(v.remaining,3)} mg remaining · ${fmt(pct,0)}%</small></div><span>${st.label}</span></div>`;
  }).join(""):`<div class="mini-item"><div><strong>No vials tracked</strong><small>Add a vial to see inventory status.</small></div></div>`;

  const recent=[
    ...data.history.map(h=>({kind:"Calculation",title:h.label,detail:h.result,created:h.created})),
    ...data.activity.map(a=>({kind:"Recorded",title:`${a.item} — ${a.step}`,detail:`${fmt(a.units,4)} units`,created:a.created}))
  ].sort((a,b)=>new Date(b.created)-new Date(a.created)).slice(0,4);
  $("#dashboardHistory").innerHTML=recent.length?recent.map(h=>`<div class="mini-item"><div><strong>${esc(h.title)}</strong><small>${esc(h.kind)} · ${esc(h.detail)}</small></div><span>${new Date(h.created).toLocaleDateString()}</span></div>`).join(""):`<div class="mini-item"><div><strong>No recent activity</strong><small>Calculations and recorded doses will appear here.</small></div></div>`;
}

function renderDatalist(){$("#libraryNames").innerHTML=data.library.map(x=>`<option value="${esc(x.name)}">`).join("")}

window.editProtocol=id=>openProtocol(data.protocols.find(x=>x.id===id));
window.deleteProtocol=id=>{const p=data.protocols.find(x=>x.id===id);if(confirm(`Delete ${p?.name||"this protocol"}? This cannot be undone unless you import a backup.`)){data.protocols=data.protocols.filter(x=>x.id!==id);saveData()}};
window.editVial=id=>openVial(data.vials.find(x=>x.id===id));
window.deleteVial=id=>{if(confirm("Delete this vial?")){data.vials=data.vials.filter(x=>x.id!==id);saveData()}};
window.useVial=id=>{const v=data.vials.find(x=>x.id===id);$("#doseVialMg").value=v.amount;$("#doseMl").value=v.liquid;$("#doseLabel").value=v.name;showView("calculate");calcDose();toast("Vial loaded into calculator")};

window.setProtocolStep=(id,stepIndex)=>{
  const p=data.protocols.find(x=>x.id===id);
  if(!p)return;
  p.currentStep=stepIndex;
  saveData();
  toast("Current protocol step updated");
};
window.loadProtocolStep=(id,stepIndex)=>{
  const p=data.protocols.find(x=>x.id===id), s=p?.steps?.[stepIndex];
  if(!p||!s)return;
  $("#doseVialMg").value=p.vialMg||"";
  $("#doseMl").value=p.liquidMl||"";
  $("#doseDesired").value=s.dose;
  $("#doseUnit").value=p.doseUnit==="units"?"mg":p.doseUnit;
  $("#doseLabel").value=`${p.name} — ${s.label}`;
  showView("calculate");
  if(p.doseUnit==="units"){
    $("#doseResult").textContent=`${fmt(s.units,3)} syringe units`;
    $("#doseSub").textContent=s.guidance||"Personal protocol step";
    $("#doseMath").textContent=`This saved protocol step specifies ${fmt(s.units,3)} syringe units.\n${s.guidance||""}`;
  }else calcDose();
  toast("Protocol step loaded");
};

$("#reminderStatusFilter").addEventListener("change",renderReminders);
$("#enableNotifications").addEventListener("click",async()=>{
  if(!("Notification" in window)) return toast("Notifications are not supported here");
  const result=await Notification.requestPermission();
  toast(result==="granted"?"Notifications enabled":"Notification permission was not granted");
});
$("#saveReminder").addEventListener("click",()=>{
  const title=$("#reminderTitle").value.trim(), date=$("#reminderDate").value, time=$("#reminderTime").value;
  if(!title||!date||!time)return toast("Title, date, and time are required");
  const id=$("#reminderId").value;
  const reminder={
    id:id||uid(),profile:$("#reminderProfile").value,title,date,time,
    repeat:$("#reminderRepeat").value,notes:$("#reminderNotes").value.trim(),lastFired:"",completed:false,completedAt:"",completionCount:0
  };
  const i=data.reminders.findIndex(r=>r.id===id);
  if(i>=0)data.reminders[i]=reminder;else data.reminders.unshift(reminder);
  resetReminderForm();
  saveData();
  toast(i>=0?"Reminder updated":"Reminder saved");
});
function resetReminderForm(){
  $("#reminderId").value="";
  $("#reminderFormTitle").textContent="Create reminder";
  $("#saveReminder").textContent="Save reminder";
  $("#cancelReminderEdit").classList.add("hidden");
  $("#reminderTitle").value="";
  $("#reminderDate").value="";
  $("#reminderTime").value="";
  $("#reminderRepeat").value="none";
  $("#reminderNotes").value="";
}
$("#cancelReminderEdit").addEventListener("click",resetReminderForm);
window.editReminder=id=>{
  const r=data.reminders.find(x=>x.id===id);
  if(!r)return;
  $("#reminderId").value=r.id;
  $("#reminderFormTitle").textContent="Edit reminder";
  $("#saveReminder").textContent="Update reminder";
  $("#cancelReminderEdit").classList.remove("hidden");
  $("#reminderProfile").value=r.profile;
  $("#reminderTitle").value=r.title;
  $("#reminderDate").value=r.date;
  $("#reminderTime").value=r.time;
  $("#reminderRepeat").value=r.repeat;
  $("#reminderNotes").value=r.notes||"";
  showView("reminders");
  $("#reminderTitle").focus();
};
function reminderDateTime(r){return new Date(`${r.date}T${r.time}:00`)}
function renderReminderStats(){
  const now=new Date();
  const active=data.reminders.filter(r=>!r.completed);
  const due=active.filter(r=>reminderDateTime(r)<=now);
  const completed=data.reminders.filter(r=>r.completed);
  $("#activeReminderCount").textContent=active.length;
  $("#dueReminderCount").textContent=due.length;
  $("#completedReminderCount").textContent=completed.length;
}
function renderReminders(){
  renderReminderStats();
  const now=new Date();
  const filter=$("#reminderStatusFilter")?.value||"active";
  let items=[...data.reminders];
  if(filter==="active")items=items.filter(r=>!r.completed);
  if(filter==="due")items=items.filter(r=>!r.completed&&reminderDateTime(r)<=now);
  if(filter==="completed")items=items.filter(r=>r.completed);
  items.sort((a,b)=>{
    if(a.completed!==b.completed)return a.completed?1:-1;
    return reminderDateTime(a)-reminderDateTime(b);
  });
  $("#reminderList").innerHTML=items.length?items.map(r=>{
    const due=!r.completed&&reminderDateTime(r)<=now;
    const status=r.completed?`<span class="completed-badge">Completed</span>`:due?`<span class="due-badge">Due</span>`:"";
    return `<article class="item-card ${due?"alert-due":""} ${r.completed?"reminder-complete":""}">
      <div>
        <span class="chip">${esc(r.profile)}</span>
        <span class="chip">${esc(r.repeat)}</span>
        ${status}
        <h3>${esc(r.title)}</h3>
        <p>${new Date(`${r.date}T${r.time}`).toLocaleString()}</p>
        ${r.notes?`<p>${esc(r.notes)}</p>`:""}
        ${r.completedAt?`<p class="muted">Completed ${new Date(r.completedAt).toLocaleString()}</p>`:""}
      </div>
      <div class="item-actions">
        ${r.completed
          ?`<button class="secondary" onclick="reopenReminder('${r.id}')">Reopen</button>`
          :`<button class="record-btn" onclick="completeReminder('${r.id}')">Mark done</button><button class="secondary" onclick="editReminder('${r.id}')">Edit</button><button class="secondary" onclick="snoozeReminder('${r.id}')">Snooze 1 hour</button>`}
        <button class="danger" onclick="deleteReminder('${r.id}')">Delete</button>
      </div>
    </article>`;
  }).join(""):`<div class="card muted">No reminders match this view.</div>`;
}
function advanceReminder(r){
  const d=reminderDateTime(r);
  if(r.repeat==="daily") d.setDate(d.getDate()+1);
  else if(r.repeat==="weekly") d.setDate(d.getDate()+7);
  else if(r.repeat==="mwf"){
    do{d.setDate(d.getDate()+1)}while(![1,3,5].includes(d.getDay()));
  } else return false;
  r.date=d.toISOString().slice(0,10);
  return true;
}
function checkReminders(){
  const now=new Date(), key=now.toISOString().slice(0,16);
  let changed=false;
  data.reminders.forEach(r=>{
    if(r.completed)return;
    if(reminderDateTime(r)<=now && r.lastFired!==key){
      r.lastFired=key;
      toast(`${r.profile}: ${r.title}`);
      if(Notification.permission==="granted") new Notification(`Beauty & Beast Wellness — ${r.profile}`,{body:r.title+(r.notes?`\n${r.notes}`:""),icon:"assets/icons/icon.svg"});
      if(advanceReminder(r)) r.lastFired="";
      changed=true;
    }
  });
  if(changed){localStorage.setItem(STORAGE_KEY,JSON.stringify(data));renderReminders()}
}

window.completeReminder=id=>{
  const r=data.reminders.find(x=>x.id===id);
  if(!r)return;
  r.completionCount=(r.completionCount||0)+1;
  r.completedAt=new Date().toISOString();
  if(r.repeat&&r.repeat!=="none"){
    const advanced=advanceReminder(r);
    if(advanced){
      r.completed=false;
      r.completedAt="";
      r.lastFired="";
      saveData();
      toast("Completed and next reminder scheduled");
      return;
    }
  }
  r.completed=true;
  saveData();
  toast("Reminder completed");
};
window.reopenReminder=id=>{
  const r=data.reminders.find(x=>x.id===id);
  if(!r)return;
  r.completed=false;
  r.completedAt="";
  r.lastFired="";
  saveData();
  toast("Reminder reopened");
};

window.snoozeReminder=id=>{
  const r=data.reminders.find(x=>x.id===id);
  if(!r)return;
  const d=new Date(`${r.date}T${r.time}:00`);
  d.setHours(d.getHours()+1);
  r.date=d.toISOString().slice(0,10);
  r.time=d.toTimeString().slice(0,5);
  r.lastFired="";
  saveData();
  toast("Reminder snoozed for 1 hour");
};
window.deleteReminder=id=>{data.reminders=data.reminders.filter(x=>x.id!==id);saveData()};

window.deleteHistory=id=>{data.history=data.history.filter(x=>x.id!==id);saveData()};
function esc(s=""){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[c]))}
